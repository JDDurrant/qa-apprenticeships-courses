package starter;

public class NestedLoopPractice {

	public static void main(String[] args) {
        // write code to produce the following output
        // 1   2   3   4   5   6   7   8   9  10
        // 2   4   6   8  10  12  14  16  18  20
        // .....
        // 9  18  27  36  45  54  63  72  81  90
        //10  20  30  40  50  60  70  80  90 100
        // i.e. all the 'tables' up to 10

	}

}
