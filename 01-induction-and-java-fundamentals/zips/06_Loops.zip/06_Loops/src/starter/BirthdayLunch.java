package starter;

public class BirthdayLunch {

	public static void main(String[] args) {
		double originalFunds = 100.00;
        double priceOfNextMeal = 12.00;       
        
        System.out.printf("I can entertain %d guests (incl myself) from %.2f and will have %.2f towards a taxi home\n");


        // when you have time

        //System.out.printf("The average price of each meal was %.2f\n");
        //System.out.printf("The cheapest meal was %.2f\n");

	}

}
