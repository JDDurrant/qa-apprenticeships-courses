package starter;

import java.util.Scanner;

public class KidsInCandyStore_Part1 {

	public static void main(String[] args) {
		
		
		int price;
		int money;
		

	}

	static int getInteger(String message, Scanner s) {

		// dummy statement so that starter code compiles at the beginning
		return -999;

	}

}
