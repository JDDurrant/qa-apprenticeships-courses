package starter;

public class DeskAllocation {

	public static String[][] deskNames;

	public static String[] names = 
		{ "Amy", "Ben", "Carly", "Danesha", "Evy", "Faroukh", 
		  "Greg", "Heather", "Ivy", "Jaz", "Keith", "Monica",
		  "Nick" }; // 13 names!

	public static void main(String[] args) {
		// initialise and size the array at 3 rows * 4 columns

		allocateAllDesks();

		displayDeskMap();

		searchDesks("Jaz");
		searchDesks("Nick");

	}

	public static void allocateAllDesks() {

		
	}

	// called from allocateAllDesks()
	public static void allocateDesk(String name) {

		
	}

	public static void displayDeskMap() {

		
	}

	public static void searchDesks(String name) {

		
	}

	public static void clearAllDesks() {

		
	}

}
