package starter;

public class Numbers {

	public static void main(String[] args) {
		// Create and initialise an array of 8 ints

		// Go off and write the printNumbers method
		// THEN you can Invoke it from here

		// Ask the user to enter a number (and ensure that it is numeric)
		// Invoke your numberFinder method and check
		// the return value from it to see if the number was found
		// printing out an appropriate message

	} // end of main method

	// Write the printNumbers method

}
