package starter.WorkingWithMoney;

class Program {
    public static void main(String[] args) {
      // to be used in Part 1 of money 
      //testingWhenOnlyPence();



      // to be used in Part 2 after Pounds are introduced as parameters  
      //testingWhenPoundsAndPence(); 
    }
    
    private static void testingWhenOnlyPence() {  
      //Money m1;
      //m1 = new 
      //System.out.println("???");
      //System.out.printf("Expected %s Actual %s\n",?,?);
      
    }
     
    private static void testingWhenPoundsAndPence() {

    }
  }