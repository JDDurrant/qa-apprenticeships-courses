package starter;

import java.util.Scanner;

public class TheLunchQueue {

	public static void main(String[] args) {
		System.out.println("What main dish would you like?");
		 

		//System.out.println("How many roast potatoes?");
      
		//System.out.println("How many brussel sprouts?");

	     
	    // Put any display of final output (printf) under here!
		

	}

}
