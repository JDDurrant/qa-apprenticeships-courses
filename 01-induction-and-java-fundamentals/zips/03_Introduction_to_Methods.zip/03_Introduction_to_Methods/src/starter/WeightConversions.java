package starter;

public class WeightConversions {

	public static void main(String[] args) {
        //ConvertInputToStonesPounds();

        //ConvertKgsToStonesPounds();

        //ConvertStonesPoundsToKgs();

	}
    private static void ConvertInputToStonesPounds()
    {
        System.out.printf("%d stones %d pounds" );
    }

    private static void ConvertKgsToStonesPounds()
    {
        double conversionFactorKgsToLbs = 2.20462;

        System.out.printf("%d stones %d pounds");
    }

    private static void ConvertStonesPoundsToKgs()
    {
        double conversionFactorKgsToLbs = 2.20462;

        System.out.printf("%d kg" );
    }
}
