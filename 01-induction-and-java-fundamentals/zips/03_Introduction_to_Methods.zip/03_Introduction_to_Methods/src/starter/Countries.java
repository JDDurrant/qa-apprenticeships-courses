package starter;

public class Countries {
	public static int Finland() {
		return 1000;
	}

	public static double Chile() {
		return 400;
	}

	public static String Russia() {
		return "Nineteen Twenty-Three";
	}

	public static int Mongolia() {
		return 1211;
	}

	public static String Zimbabwe() {
		return "$Z2,621,984,228";

	}
}
