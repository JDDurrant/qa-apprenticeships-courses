package Starter;

public enum HolidayDestination {
//			Africa,
//	        Asia,
//	        NorthAmerica,
//	        Europe,
//	        SouthAmerica,
//	        Australia,
//	        Other;
}

