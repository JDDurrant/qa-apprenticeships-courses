package Starter;

public class StringPractice {

	public static void main(String[] args) {
		// Declare and create a String called name with the exact value 'Fred'

		// Display its 3rd character - 'e'
		
		
		// In lower case
		
		// In upper case
		
		// Iterate over it
		

		// startsWith
		
		// endsWith
		
		// indexOf - success
		
		// indexOf - fail
		
		// concatenation
		
		// Stringbuilder
		

	}

}
