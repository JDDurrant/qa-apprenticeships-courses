package Solution;

public enum HolidayDestination {
			Africa,
	        Asia,
	        NorthAmerica,
	        Europe,
	        India,
	        SouthAmerica,
	        Australia,
	        Other;
}

