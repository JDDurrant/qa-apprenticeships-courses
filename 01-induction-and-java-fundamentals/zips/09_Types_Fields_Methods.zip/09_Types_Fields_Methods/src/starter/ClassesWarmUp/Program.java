package starter.ClassesWarmUp;

public class Program {

	public static void main(String[] args) {
        // Section 1 - CAR
        // Declare 2 variables of type Car call them 'c1' and 'c2'

        // Give each variable a value


        // Just display on the console the model of each car 





        // Section 2 - PERSON
        // A variable of type Person
        Person p1;
        // Give it a value

        // Display the persons details 






        // Section 3 - COURSE
        // A variable of type course ,initialise it on this line
        Course course; 
        // Display the course's details
        




        // Section 4 - static vs instance
        


	}

}
