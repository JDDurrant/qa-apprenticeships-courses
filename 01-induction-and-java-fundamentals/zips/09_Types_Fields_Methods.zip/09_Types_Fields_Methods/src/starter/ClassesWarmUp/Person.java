package starter.ClassesWarmUp;

public class Person {
    private String name;
    // author a 2nd field 'age'
    
    // author a constructor that receives a name an age and stores them
    


    public String getDetails()
    {
        return String.format("???? %s etc");
    }
}
