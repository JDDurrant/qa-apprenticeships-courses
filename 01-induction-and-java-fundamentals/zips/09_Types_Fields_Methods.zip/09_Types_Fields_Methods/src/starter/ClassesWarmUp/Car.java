package starter.ClassesWarmUp;

public class Car {
    // author a constructor that receives a model and stores it
    




    //public string getModel()
    //{
    //    
    //}
}
